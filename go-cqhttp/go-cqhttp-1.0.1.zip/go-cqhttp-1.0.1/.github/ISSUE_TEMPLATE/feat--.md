---
name: 新功能提议
about: 提出新功能
title: ''
labels: feature request
assignees: ''

---

**环境信息**
<!-- 请尽量填写 -->
go-cqhttp版本: 

**需要添加的功能内容**
<!-- 请在这里详细描述新功能的实现方法 -->
